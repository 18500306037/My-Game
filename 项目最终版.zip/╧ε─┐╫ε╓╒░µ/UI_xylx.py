# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\Python\Desktop\1.0\main.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QIcon

class Main1(object):


    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(530, 450)

        # #标题标签
        # self.setWindowTitle("和你心有灵犀呀")
        # 标题
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(135, 30, 250, 51))
        font = QtGui.QFont()
        font.setPointSize(25)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        font.setFamily("华文彩云")
        self.label.setFont(font)
        self.label.setObjectName("label")

        # '快速游戏'按钮
        self.game_start_btn = QtWidgets.QPushButton(Dialog)
        self.game_start_btn.setGeometry(QtCore.QRect(160, 100, 190, 50))
        font = QtGui.QFont()
        font.setPointSize(17)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        font.setFamily("幼圆")
        self.game_start_btn.setFont(font)
        self.game_start_btn.setObjectName("pushButton")
        # self.game_start_btn.setText("<font color=%s>%s</font>" % ("red", "helloworld"))

        # '时间模式'按钮
        self.game_start_time_btn = QtWidgets.QPushButton(Dialog)
        self.game_start_time_btn.setGeometry(QtCore.QRect(160, 160, 190, 50))
        font = QtGui.QFont()
        font.setFamily("幼圆")
        font.setPointSize(17)
        self.game_start_time_btn.setFont(font)
        self.game_start_time_btn.setObjectName("pushButton_2")

        # '竞猜模式'按钮
        self.game_start_game_btn = QtWidgets.QPushButton(Dialog)
        self.game_start_game_btn.setGeometry(QtCore.QRect(160, 220, 190, 50))
        font = QtGui.QFont()
        font.setFamily("幼圆")
        font.setPointSize(17)
        self.game_start_game_btn.setFont(font)
        self.game_start_game_btn.setObjectName("pushButton_3")

        # '退出游戏'按钮
        self.break_game_btn = QtWidgets.QPushButton(Dialog)
        self.break_game_btn.setGeometry(QtCore.QRect(160, 280, 190, 50))
        font = QtGui.QFont()
        font.setFamily("黑体")
        font.setPointSize(17)
        self.break_game_btn.setFont(font)
        self.break_game_btn.setObjectName("pushButton_4")

        # '更多模式'按钮
        self.more_more_mode_btn = QtWidgets.QPushButton(Dialog)
        self.more_more_mode_btn.setGeometry(QtCore.QRect(160, 340, 190, 50))
        font = QtGui.QFont()
        font.setFamily("幼圆")
        font.setPointSize(17)
        self.more_more_mode_btn.setFont(font)
        self.more_more_mode_btn.setObjectName("pushButton_5")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "和你心有灵犀呀"))
        Dialog.setWindowIcon(QIcon("./images/cartoon1.ico"))
        self.label.setText(_translate("Dialog", "和你心有灵犀呀"))
        self.game_start_btn.setText(_translate("Dialog", "快速游戏"))
        self.game_start_btn.setStyleSheet("color:rgb(140,120,160)")

        self.game_start_time_btn.setText(_translate("Dialog", "时间模式"))
        self.game_start_time_btn.setStyleSheet("color:rgb(110,170,130)")

        self.game_start_game_btn.setText(_translate("Dialog", "竞猜模式"))
        self.game_start_game_btn.setStyleSheet("color:rgb(140,120,160)")

        self.break_game_btn.setText(_translate("Dialog", "退出游戏"))
        self.break_game_btn.setStyleSheet("color:rgb(110,170,130)")

        self.more_more_mode_btn.setText(_translate("Dialog", "游戏说明"))
        self.more_more_mode_btn.setStyleSheet("color:rgb(140,120,160)")

        Dialog.setStyleSheet("#Dialog{border-image:url(images/主页.png);}")

    # def use_palette(self,Dialog):
    #     window_pale = QtGui.QPalette(Dialog)
    #     window_pale.setBrush(self.backgroundRole(Dialog), QtGui.QBrush(QtGui.QPixmap("./images/红毛.jpg")))
    #     self.setPalette(window_pale)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Main1()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

