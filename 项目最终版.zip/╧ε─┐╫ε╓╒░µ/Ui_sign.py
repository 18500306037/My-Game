# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\Python\Desktop\1.0\base\login.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
from PyQt5.QtCore import Qt
from PyQt5 import QtCore, QtGui, QtWidgets

class Login_Window(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        # Dialog.resize(410, 260)
        Dialog.resize(490,367)
        Dialog.setWindowFlags(Qt.FramelessWindowHint )
        Dialog.setStyleSheet('#Dialog{border-image:url(login1.jpg);}')
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(150,230,190,35))
        self.pushButton.setObjectName("pushButton")
        self.pushButton.setStyleSheet("color:#F0FFFF;background-color:#99EE3A8C")
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(150,155,190,25))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.setStyleSheet("color:#F0FFFF;background-color:#00F0FFFF")
        self.lineEdit_2 = QtWidgets.QLineEdit(Dialog)
        self.lineEdit_2.setGeometry(QtCore.QRect(150,192,190,25))
        self.lineEdit_2.setStyleSheet("color:#F0FFFF;background-color:#00F0FFFF")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(150,270,190,25))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.setStyleSheet("color:#FF3E96;background-color:#0000BFFF")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(60, 70, 367, 70))
        self.label_3.setAlignment(Qt.AlignCenter)
        font = QtGui.QFont()
        font.setFamily("Snap ITC")
        font.setPointSize(26)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet("color:white")
        self.label_3.setObjectName("label_3")
        
        self.exitbt = QtWidgets.QPushButton(Dialog)
        self.exitbt.setFixedSize(25,25)
        self.exitbt.move(465,0)
        # self.exitbt.clicked.connect(QCoreApplication.instance().quit)
        #为退出按钮设置图片234.56.60.67.76.152
        exicon = QtGui.QIcon()
        exicon.addPixmap(QtGui.QPixmap("xxx1.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.exitbt.setIcon(exicon)
        self.exitbt.setIconSize(QtCore.QSize(50, 80))
        self.exitbt.setAutoRepeatDelay(200)
        self.exitbt.setStyleSheet("border: 0px")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.pushButton.setText(_translate("Dialog", "登录"))
        self.lineEdit.setPlaceholderText(_translate("Dialog", "账号"))
        self.lineEdit_2.setPlaceholderText(_translate("Dialog", "密码"))
        self.pushButton_2.setText(_translate("Dialog", "一键注册"))
        # self.label.setText(_translate("Dialog", "注册账号"))
        # self.label_2.setText(_translate("Dialog", "忘记密码"))
        self.label_3.setText(_translate("Dialog", "Welcome !!"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Login_Window()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

