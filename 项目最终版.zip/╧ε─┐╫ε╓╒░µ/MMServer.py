from socket import *
from multiprocessing import Process
import sys,time
from Mysqlpython import *
import time
import random
import copy

#创建服务器类
class MMServer(object):
    def __init__(self,s):
        self.s = s

    def do_zhuce(self,s,addr,msgl):
        print(msgl)
        #进入数据库匹配用户名是否存在
        mysql = Mysqlpython("project")
        sql = "select * from admin where name='%s';"%msgl[1]
        r = mysql.chaxun(sql)
        #r格式((1,"小风"，“1234),()...)
        if r:
            self.s.sendto("用户名已存在".encode(),addr)
        else:
            print("用户名合法，可以注册")
            sql = "insert into admin(name,mima) values('%s','%s');"%(msgl[1],msgl[2])
            mysql.zhixing(sql)
            self.s.sendto("注册成功".encode(),addr)
            
    def do_denglu(self,s,user,addr,msgl):
        print(msgl)
        name = msgl[1]
        mima = msgl[2]
        #进入数据库匹配用户名是否存在
        mysql = Mysqlpython("project")
        sql = "select mima from admin where name = '%s'"%msgl[1]
        r = mysql.chaxun(sql)
        #r格式((1,"小风"，“1234),()...)
        # if not r:
            # self.s.sendto("用户名错误，请重新输入".encode(),addr)
        # else:
        if r:
            if r[0][0] == mima:
                print(name,"登陆成功")
                #每登陆一个用户，就将该用户存入字典user，表示在线用户
                user[addr] = name
                print(user)
                self.s.sendto("登陆成功".encode(),addr)
                print("********************")
                
            else:
                print('登录失败')
                self.s.sendto("密码错误，请重新输入".encode(),addr)
                print('rbucunz')
    
    def do_liaotian(self,s,user,addr,msgl):
        #user格式{("127.0.0.1",60789):"用户名"}
        print(user,msgl)
        for i in user:
            for j in msgl[1]:
                if msgl[1] = '***'
            #重新组织消息，加上发送人
            mss = "\n用户 %s 说: %s"%(user[addr],msgl[1])
            self.s.sendto(mss.encode(),i)

    # def do_updata(self,s,addr,msgl):
    def do_updata(self,msgl):
        mysql = Mysqlpython("project")
        sql = "select CJ from admin where name = '%s'"%msgl[0]
        r = str(mysql.chaxun(sql))
        r=eval(r)
        print(type(r[0]))
        if int(msgl[1])>int(r[0][0]):
            sql = "update admin set CJ=%d where  name = '%s'"%(int(msgl[1]),msgl[0])
            r = str(mysql.zhixing(sql))
            print("恭喜获得生涯最高分数")
        # else:
            # sss="你没有超过你的最高分"
        # self.s.sendto(sss.encode(),addr)

    def do_updata_wzq(self,msgl):
        mysql = Mysqlpython("project")
        sql = "select name,WZQ from admin where name = '%s'"%msgl[1]
        r = mysql.chaxun(sql)
        print(r)
        rr=int(r[0][1])+1
        sql = "update admin set WZQ=%d where  name = '%s'"%(rr,msgl[1])
        n=mysql.zhixing(sql)

    def do_paihangbang(self,s,addr):
        r1 = ['CJ']
        r2 = ['WZQ']
        mysql = Mysqlpython("project")
        sql1 = "select name,CJ from admin order by CJ DESC limit 3"
        sql2 = "select name,WZQ from admin order by WZQ DESC limit 3"
        r1 += mysql.chaxun(sql1)
        r2 += mysql.chaxun(sql2)
        print(r1)
        print(r2)
        r1 = str(r1)
        r2 = str(r2)
        self.s.sendto(r1.encode(),addr)
        self.s.sendto(r2.encode(),addr)
        # update admin set CJ=500 where id='2';

    def handler(self):
        #创建新端口
        addr1 = ("127.0.0.1",9999)
        s_dati = socket(AF_INET,SOCK_DGRAM)
        s_dati.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
        s_dati.bind(addr1)

        print("答题游戏正在监听端口9999")
        port = 10000
        #创建保存用户信息的地址字典d,存放格式{地址:[用户名,分数]}
        d = {}
        #初始化用户本局游戏的分数
        count_0=0

        while 1:
            print("当前用户等待游戏的用户列表",d)
            #接收消息,解析游戏标志
            msg,addr = s_dati.recvfrom(4096)#-------------------------
            # msgl = msg.decode().split(":") #[name,CJ]
            msgl = eval(msg.decode()) #['DTG',dl.name]
            
            # print(addr,"111")
            d[addr] = [msgl[1],count_0]

            print("当前用户等待游戏的用户列表",d)

            # #创建房间套接字,绑定新端口
            # addr2 = ("",port)
            # s2 = socket(AF_INET,SOCK_DGRAM)
            # s2.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
            # s2.bind(addr2)

            # #发送游戏房间的端口号给用户
            # s_dati.sendto(str(port).encode(),addr)#=======================
            print("%d号房间准备中..."%port)
            if len(d) >= 2:
                p = Process(target = self.fj,args=(d,port))
                p.start()
                print("%d号房间已经开始游戏"%port)
                # 开始游戏后清空当前的等待用户列表
                d={}
                port += 1
                # p.join()
                
    def fj(self,d,port):
        #创建房间套接字,绑定新端口
        addr2 = ("",port)
        s_dt_fj = socket(AF_INET,SOCK_DGRAM)
        s_dt_fj.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
        s_dt_fj.bind(addr2)
        s_dt_fj.settimeout(0.01)
        # for i in d:
        #     try:
        #         #发送游戏房间的端口号给用户
        #         s_dati.sendto(str(port).encode(),addr)#=======================
        #     except:
        #         print('有人没有接收端口号')
        #从题库中搜索题目，将每个题目和答案以元组形式存放在列表L中
        L = []
        with open(r"C:\Users\Python\Desktop\AID1808\中期项目\项目最终版\答题游戏题库.txt",'r') as f:
            for line in f:
                #ss列表格式["题目","","答案"]
                ss = line.strip().split(" ")
                timu = ss[0]
                ss.remove(timu)
                daan = " ".join(ss).strip()
                L.append([timu,daan])

        #创建字典用于保存用户分数,格式name:count
        # cj = {}
        #获取每个用户的用户名和分数存放在字典中
        FSdic={}
        print('d',d)
        msgl=''
        while True:
            TZZlist=['TZZ',]
            for i in d:
                # d[addr] = [msgl[1],count_0]
                # FSlist+=[d[i]]
                FSdic[d[i][0]]=d[i][1]
            print('FSdic',FSdic)                
            #选题,l格式[题目，答案]
            l = random.sample(L,1) 
            print(l) 
            L.remove(l[0])
            TZZlist.append(FSdic)
            for i in d:
                # print(i)
                # 发送题目
                try:
                    s_dt_fj.sendto(str(['TM',l[0][0]]).encode(),i) #===========
                    print("题目发送啦")
                except:
                    # print('FSdic',FSdic)                
                    # print('d',d)
                    for k in FSdic:
                        if d[i][0] ==k:
                            del FSdic[i]
                            print('移除了掉线的人')
                    del d[i]
                if d[i]:
                    print(TZZlist)
                    s_dt_fj.sendto(str(TZZlist).encode(),i)#=================
                    print("已更新剩余挑战者")
            # time.sleep(2)
            start_t=time.time()
            msgl=''
            #系统循环等待了一段时间,
            while 1:
                stop_time=time.time()
                if stop_time-start_t>5:
                    break
                # 接收用户发送的答案,
                print('接收答案中',end='\r')
                try:
                    msg,addr = s_dt_fj.recvfrom(4096)  #------------------------
                    print('收到一了个')
                    msgl=eval(msg.decode())
                    if msgl[2] == l[0][1]:
                        d[addr][1]+=10
                        # print('d',d)
                        print('有人答对了')
                        # print('d[addr][1]',d[addr][1])
                        # print('d[addr]',d[addr])
                        msgl=['JX','挑战继续']
                        s_dt_fj.sendto(str(msgl).encode(),addr)#===============
                    else:
                        print('有人答错了')
                        try:
                            # 答错的返回淘汰,
                            msgl=["你被淘汰了,此次得分:%d分"%d[addr][1]]
                            s_dt_fj.sendto(str(msgl).encode(),addr)#===============
                        finally:
                            print('shanchushi-d[addr]',d[addr])
                            self.do_updata(d[addr])
                            # 并从挑战者中删除
                            del d[addr]
                except:
                    pass
            if len(d) == 0 or not msgl:
                print('结束了一场游戏')
                break

    #五子棋
    def handler5(self,L,s_5zq):
        addr1 = L[0]
        addr2 = L[1]
        s_5zq.sendto(b"begin:1",addr1)
        s_5zq.sendto(b"begin:2",addr2)

        #服务端开始游戏后,设定addr1先走(黑棋),addr后走(白棋)
        black = 1 
        white = 2
        EMPTY = 0
        board = [[]] * 15
        for row in range(len(board)):
            board[row] = [EMPTY] * 15
        while True:
            data,addr = s_5zq.recvfrom(1024)
            print(data.decode()) 
            l = data.decode().split("#")
            row = int(l[0])
            col = int(l[1])
            if addr == addr1:
                board[row][col] = black
                if self.is_black_win(board):            
                    s_5zq.sendto(b'Y',addr1)
                    s_5zq.sendto(b'N',addr2)
                else:
                    print("向客户端2发送数据")
                    s_5zq.sendto(data,addr2)
            elif addr == addr2:
                board[row][col] = white
                if self.is_white_win(board):
                    s_5zq.sendto(b'Y', addr2)
                    s_5zq.sendto(b'N', addr1)
                else:
                    print("向客户端1发送数据")
                    s_5zq.sendto(data, addr1)
            elif data.decode() == "end":
                s_5zq.sendto("对方退出游戏".encode(),add2)
        s_5zq.close()

    def is_black_win(self,board):
        for n in range(15):
            # 判断垂直方向胜利
            flag = 0
            # flag是一个标签，表示是否有连续以上五个相同颜色的棋子
            for b in board:
                if b[n] == 1:
                    flag += 1
                    if flag == 5:
                        print('黑棋胜')
                        return True
                else:
                # else表示此时没有连续相同的棋子，标签flag重置为0
                    flag = 0
            # 判断水平方向胜利
            flag = 0
            for b in board[n]:
                if b == 1:
                    flag += 1
                    if flag == 5:
                        print('黑棋胜')
                        return True
                else:
                    flag = 0
            # 判断正斜方向胜利
            for x in range(4, 25):
                flag = 0
                for i,b in enumerate(board):
                    if 14 >= x - i >= 0 and b[x - i] == 1:
                        flag += 1
                        if flag == 5:
                            print('黑棋胜')
                            return True
                    else:
                        flag = 0
            #判断反斜方向胜利
            for x in range(11, -11, -1):
                flag = 0
                for i,b in enumerate(board):
                    if 0 <= x + i <= 14 and b[x + i] == 1:
                        flag += 1
                        if flag == 5:
                            print('黑棋胜')
                            return True
                    else:
                        flag = 0
            for x in range(11, -11, -1):
                flag = 0
                for i,b in enumerate(board):
                    if 0 <= x + i <= 14 and b[x + i] == 2:
                        flag += 1
                        if flag == 5:
                            print('白棋胜')
                            return False
                    else:
                        flag = 0
        return False

    def is_white_win(self,board):
        for n in range(15):
            # 判断垂直方向胜利
            flag = 0
            # flag是一个标签，表示是否有连续以上五个相同颜色的棋子
            for b in board:
                if b[n] == 2:
                    flag += 1
                    if flag == 5:
                        print('白棋胜')
                        return True
                else:
                    flag = 0
            # 判断水平方向胜利
            flag = 0
            for b in board[n]:
                if b == 2:
                    flag += 1
                    if flag == 5:
                        print('白棋胜')
                        return True
                else:
                    flag = 0
            # 判断正斜方向胜利
            for x in range(4, 25):
                flag = 0
                for i,b in enumerate(board):
                    if 14 >= x - i >= 0 and b[x - i] == 2:
                        flag += 1
                        if flag == 5:
                            print('白棋胜')
                            return True
                    else:
                        flag = 0 
            #判断反斜方向胜利       
            for x in range(11, -11, -1):
                flag = 0
                for i,b in enumerate(board):
                    if 0 <= x + i <= 14 and b[x + i] == 2:
                        flag += 1
                        if flag == 5:
                            print('白棋胜')
                            return True
                    else:
                        flag = 0
        return False

    def main5(self):
        ADDR = ('127.0.0.1', 33333) 
        s_5 = socket(AF_INET, SOCK_DGRAM)
        s_5.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
        s_5.bind(ADDR)
    
        port = 20000
        L = []
        while True:
            
            d_z={}
            print("五子棋正在监听端口33333...")
            msg,addr = s_5.recvfrom(1024)
            print(addr,"连接")
            msgl=eval(msg)
            if msgl[0]=='WZQ':
                # d_z[addr]=[msg[1]]
                L.append(addr)
            
            if len(L) == 2:
                #有两个用户时,创建新端口和新游戏进程
                ADDR2 = ('',port)
                s_5zq = socket(AF_INET,SOCK_DGRAM)
                s_5zq.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
                s_5zq.bind(ADDR2)  

                port += 1
                p = Process(target = self.handler5, args=(L,s_5zq))
                p.start()
                print("进入游戏进程")
                L.clear()
            else:
                s_5.sendto("等待其他玩家连接".encode(),addr)
        s_5.close() 

#创建网络连接
def main():
    ADDR = ("127.0.0.1",55555)
    #创建套接字
    s = socket(AF_INET,SOCK_DGRAM)
    s.setsockopt(SOL_SOCKET,SO_REUSEADDR,1)
    s.bind(ADDR)

    mms = MMServer(s)
    user = {}

    # 创建子进程用于处理五子棋游戏操作
    p2 = Process(target=mms.main5)
    p2.start()

    # 创建子进程用于处理答题游戏操作
    p = Process(target=mms.handler)
    p.start()

    #主进程继续
    print("主进程正在监听端口55555...")

    while True:
        # 循环接收客户端请求,按标志信息分类处理
        msg,addr = s.recvfrom(4096)
        print(msg.decode())
        print(addr)
        # msgl = msg.decode().split(":")
        msgl = eval(msg.decode())
        if msgl[0] == "ZC":
            mms.do_zhuce(s,addr,msgl)
        elif msgl[0] == "DL":
            print("****")
            mms.do_denglu(s,user,addr,msgl)
        # elif msgl[0] =="UP":
        #     print("up....")
        #     mms.do_updata(s,addr,msgl)
        elif msgl[0] =="PHB":
            print("PHB...")
            mms.do_paihangbang(s,addr)
        elif msgl[0]=="WZQSL":
            print("WZQSL")
            mms.do_updata_wzq(msgl)
        elif msgl[0] == "Q":
            #用户下线，则删除该用户
            del user[addr]
            print(addr,"已下线")
        elif msgl[0] == "LT":
            mms.do_liaotian(s,user,addr,msgl)
        else:
            print("====")

if __name__ == "__main__":
    main()