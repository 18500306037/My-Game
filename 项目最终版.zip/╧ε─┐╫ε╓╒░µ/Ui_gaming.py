# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\Python\Desktop\1.0\gaming.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QIcon
import time
import sys

class Ui_gaming(object):
    def setupUi(self, Dialog):

        Dialog.setObjectName("Dialog")
        Dialog.resize(530, 450)
        # "答对了"按键
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(100, 270, 130, 40))
        font = QtGui.QFont()
        font.setFamily("黑体")
        font.setPointSize(13)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")

        # "下一题"按键
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(330, 270, 130, 40))
        font = QtGui.QFont()
        font.setFamily("黑体")
        font.setPointSize(13)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")

        # "返回主菜单"按键
        self.pushButton_3 = QtWidgets.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(-1000, 270, 130, 40))
        font = QtGui.QFont()
        font.setFamily("黑体")
        font.setPointSize(13)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")

        # 显示"准备开始"和"出题目"和"时间结束啦"
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(190, 80, 281, 81))
        font = QtGui.QFont()
        font.setFamily("隶书")
        font.setPointSize(27)
        self.label.setFont(font)
        self.label.setObjectName("label")

        # 显示"返回结果"
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(-1000, 80, 281, 81))
        font = QtGui.QFont()
        font.setFamily("黑体")
        font.setPointSize(17)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label")

        # 显示电子时间计时
        self.lcdNumber = QtWidgets.QLCDNumber(Dialog)
        self.lcdNumber.setGeometry(QtCore.QRect(420, 10, 71, 31))
        self.lcdNumber.setObjectName("lcdNumber")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "和你心有灵犀呀-竞猜模式"))
        Dialog.setWindowIcon(QIcon("./images/cartoon1.ico"))

        self.pushButton.setText(_translate("Dialog", "答对啦"))
        self.pushButton.setStyleSheet("color:rgb(140,120,160)")

        self.pushButton_2.setText(_translate("Dialog", "下一题"))
        self.pushButton_2.setStyleSheet("color:rgb(110,170,130)")

        self.pushButton_3.setText(_translate("Dialog", "返回主菜单"))
        self.pushButton_3.setStyleSheet("color:rgb(160,110,20)")

        self.label.setText(_translate("Dialog", "准备开始!"))
        self.label.setStyleSheet("color:rgb(190,65,35)")

        self.label_2.setText(_translate("Dialog", "返回结果"))
        Dialog.setStyleSheet("#Dialog{border-image:url(images/竞猜模式.png);}")

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_gaming()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

