from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QIcon
import time
import sys

class Ui_howtoplay(object):
    def setupUi(self, Dialog):

        Dialog.setObjectName("Dialog")
        Dialog.resize(530, 450)

        # 游戏规则
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(80, 50, 400, 81))
        font = QtGui.QFont()
        font.setFamily("方正姚体")
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setObjectName("label")

        # 时间模式游戏说明
        self.label_1 = QtWidgets.QLabel(Dialog)
        self.label_1.setGeometry(QtCore.QRect(80, 110, 281, 81))
        font = QtGui.QFont()
        font.setFamily("方正姚体")
        font.setPointSize(12)
        self.label_1.setFont(font)
        self.label_1.setObjectName("label")

        # 竞猜模式游戏说明
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(80, 180, 281, 81))
        font = QtGui.QFont()
        font.setFamily("方正姚体")
        font.setPointSize(12)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label")

        #"返回主菜单"键
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(180, 330, 130, 40))
        font = QtGui.QFont()
        font.setFamily("黑体")
        font.setPointSize(15)
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")

        # 说明
        # self.label_3 = QtWidgets.QLabel(Dialog)
        # self.label_3.setGeometry(QtCore.QRect(50, 180, 281, 81))
        # font = QtGui.QFont()
        # font.setPointSize(12)
        # self.label_3.setFont(font)
        # self.label_3.setObjectName("label")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "和你心有灵犀呀-游戏说明"))
        Dialog.setWindowIcon(QIcon("./images/cartoon1.ico"))
        self.pushButton.setText(_translate("Dialog", "返回主菜单"))
        self.pushButton.setStyleSheet("color:rgb(160,110,20)")
        self.label.setText(_translate("Dialog", '''游戏规则:用任何语言描述当前词语,让小伙伴猜出词语
                注意!描述时不得说出题目中任意一个字!!'''))
        self.label_1.setText(_translate("Dialog", "时间模式:在规定时间为答题"))
        self.label_2.setText(_translate("Dialog", "竞猜模式:在规定题量内答题"))
        Dialog.setStyleSheet("#Dialog{border-image:url(images/游戏规则.png);}")

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_howtoplay()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())