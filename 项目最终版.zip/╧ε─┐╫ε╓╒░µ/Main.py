import sys
import time
import pygame
from multiprocessing import Process
from threading import *
from random import *
from socket import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QTimer
from PyQt5.QtCore import QPropertyAnimation
from Ui_sign import *
from Ui_dati import *
from Ui_main import *
from Ui_dati import *
from Ui_gaming import *
from Ui_gaming_time import *
from Ui_howtoplay import *
from UI_xylx import *

global ADDR, s, chat_msg, s_game, ADR_dt
ADDR = ("127.0.0.1", 55555)
ADR_dt = ("127.0.0.1", 9999)
s = socket(AF_INET, SOCK_DGRAM)
s_game = socket(AF_INET, SOCK_DGRAM)

#利用pyqt的多线程, 重写方法用于接收来自于主服务的消息
# 判断后,分发消息
class BackendThread(QThread):
    update_date = pyqtSignal(str)
    update_date2 = pyqtSignal(list)
    update_date7 = pyqtSignal(list)
    def run(self):
        global chat_msg
        chat_msg = ''
        while True:
            # =========================================
            msg, addr = s.recvfrom(1024)
            try:
                ll = eval(msg.decode())
                if type(ll) == list and ll[0]=='CJ':
                    self.update_date2.emit(ll)
                elif type(ll) == list and ll[0]=='WZQ':
                    self.update_date7.emit(ll)
            except:
                # 通过下面的拼接调换,实现聊天的最新消息显示在第一行
                msg_l = msg.decode()
                msg_l += chat_msg
                chat_msg = msg_l
                print("聊天中"+msg.decode())
                self.update_date.emit(str(msg_l))

#利用pyqt的多线程, 重写方法用于接收来自于游戏服务的消息
class Zh_Game_Thread(QThread):
    update_date3 = pyqtSignal(str)
    update_date4 = pyqtSignal(list)
    update_date5 = pyqtSignal(list)
    update_date6 = pyqtSignal(str)
    # def __init__(self, parent=None):
    #     super(Zh_Game_Thread, self).__init__(parent)
    #     self.flag=1
    def run(self):
        msgs = ['DTG', dl.name]
        s_game.sendto(str(msgs).encode(), ADR_dt)

        while 1:
            # if self.flag==1:
            #     break
            msg, addr = s_game.recvfrom(4096)
            msgl = eval(msg)
            print(msgl)
            if msgl[0] == 'TZZ':
                # 更新显示剩余挑战者
                self.update_date5.emit(msgl)
            elif msgl[0] == 'TM' or msgl[0] == 'JX':
                # 更新显示题目
                self.update_date4.emit(msgl)
                self.update_date3.emit(str(addr))
            else:
                # 被淘汰
                self.update_date6.emit(msgl[0])

    # def stop(self,msg):
    #     self.flag=msg


# 登录注册类
class sign_main(QMainWindow, Login_Window):
    def __init__(self, parent=None):
        super(sign_main, self).__init__(parent)
        self.setupUi(self)
        self.animation = QPropertyAnimation(self, b'windowOpacity')
        self.animation.setDuration(800)  # 持续时间0.8秒
        # 执行淡入
        self.doShow()

        self.lineEdit_2.setEchoMode(QLineEdit.Password)
        self.pushButton.clicked.connect(self.send_dl)
        self.pushButton_2.clicked.connect(self.send_zc)
        self.exitbt.clicked.connect(self.close)

    # 此方法,实现登录功能,并在登录成功后,切换到主界面
    # 并赋值全局变量 name 方便在其他模块使用

    def send_dl(self):
        # global name,s,ADDR
        self.name = self.lineEdit.text()
        mima = self.lineEdit_2.text()
        # =======================================================
        msg = ['DL', self.name, mima]
        # s.sendto(("DL:"+self.name+":"+mima).encode(), ADDR)
        s.sendto(str(msg).encode(), ADDR)
        # 接收客户端返回的是否登录成功信息======================================
        data, addr = s.recvfrom(4096)
        if data.decode() == "登陆成功":
            print("登陆成功")
            self.showmsg('Login Success!')
            self.change_window()
        else:
            print("用户名或密码错误,请重新输入")
            self.showmsg('Logon failed!')

    # 此方法,实现注册功能
    def send_zc(self):
        name = self.lineEdit.text()
        mima = self.lineEdit_2.text()
        if name and mima:
            # ===================================
            msg = ['ZC', name, mima]
            s.sendto(str(msg).encode(), ADDR)
            # 接收客户端返回的是否注册成功信息==================================
            data, addr = s.recvfrom(4096)
            if data.decode() == "注册成功":
                print("注册成功")
                self.showmsg('注册成功,请登录')
            else:
                print("用户名已存在")
                self.showmsg(data.decode())
        else:
            self.showmsg('账号/密码不能为空!')

     # 此方法,修改登录注册界面的上方的提示信息

    def showmsg(self, data):
        self.label_3.setText(data)

    def change_window(self):
        # 隐藏登录界面
        self.close()
        # time.sleep(1)
        # 显示主窗口
        mm.show()
        # 左上角显示用户信息
        mm.uname_lab.setText('欢迎用户:'+self.name)
        # 创建聊天室接收消息的线程
        self.chat_res_start = BackendThread()
        self.chat_res_start.update_date.connect(mm.chat_show)
        self.chat_res_start.update_date2.connect(mm.toplist_show_CJ)
        self.chat_res_start.update_date7.connect(mm.toplist_show_WZQ)
        print('聊天室开始监听')
        self.chat_res_start.start()
        mm.get_toplist()

    def doShow(self):
        try:
            self.animation.finished.disconnect(self.close)
        except:
            pass
        self.animation.stop()
        # 透明度范围从0逐渐增加到1
        self.animation.setStartValue(0)
        self.animation.setEndValue(1)
        self.animation.start()


class m_main(QMainWindow, main_MainWindow):
    def __init__(self, parent=None):
        super(m_main, self).__init__(parent)
        self.setupUi(self)
        self.dati_game.clicked.connect(self.start_zh)
        self.lineEdit.setPlaceholderText('输入你想说的话...')
        self.send_msg_btn.clicked.connect(self.chat_send)
        self.pushButton_5.clicked.connect(self.wuzq)
        self.lineEdit.editingFinished.connect(self.chat_send)
        self.toplist_lb.linkActivated.connect(self.get_toplist)
        self.pushButton_7.clicked.connect(self.xylx)

    def xylx(self):
        a.show()

    def wuzq(self):
        wzq_66 = Chessboard()
        wzq_66.start_5(dl.name)

    # 开始答题游戏
    def start_zh(self):
        zh.show()

    def chat_show(self, data):
        print('更新了一次聊天')
        # 刷新聊天框中的信息
        self.textBrowser.setText(data)

    # 聊天发消息
    def chat_send(self):
        msg = self.lineEdit.text()
        if msg:
            # 将输入框中的信息,发送给主服务器
            msgl = ['LT', msg]
            s.sendto(str(msgl).encode(), ADDR)
            # 清空输入框中的内容
            self.lineEdit.clear()

    def get_toplist(self):
        msg = ['PHB', ]
        s.sendto(str(msg).encode(), ADDR)

    def toplist_show_CJ(self, data):
        # data = eval(data)
        self.label_4.setText("第一名: %s  最高: %s分" % (data[1][0], data[1][1]))
        self.label_5.setText("第二名: %s  最高: %s分" % (data[2][0], data[2][1]))
        self.label_6.setText("第三名: %s  最高: %s分" % (data[3][0], data[3][1]))
        print('刷新了排行榜')
    
    def toplist_show_WZQ(self, data):
        # data = eval(data)
        self.label_10.setText("第一名: %s  胜场数: %s" % (data[1][0], data[1][1]))
        self.label_9.setText("第二名: %s  胜场数: %s" % (data[2][0], data[2][1]))
        self.label_8.setText("第三名: %s  胜场数: %s" % (data[3][0], data[3][1]))
        print('刷新了排行榜')


#主页面
class XYLX(QMainWindow,Main1):
    def __init__(self,parent=None):
        super(XYLX,self).__init__(parent)

        #按钮选择
        self.setupUi(self)
        self.game_start_btn.clicked.connect(self.game_start)
        self.game_start_time_btn.clicked.connect(self.game_start_time)
        self.game_start_game_btn.clicked.connect(self.game_start_game)
        self.break_game_btn.clicked.connect(self.break_game)
        self.more_more_mode_btn.clicked.connect(self.How_to_play)

    #快速游戏
    def game_start(self):
        self.close()
        num = randint(0, 1)
        if num == 1:
            gst.show()
            self.t = Thread(target=gst.time_make)
            self.t.start()
        else:
            gsg.show()
            self.t2 = Thread(target=gsg.time_make)
            self.t2.start()

    def game_start_time(self):
        self.close()
        gst.show()
        self.t = Thread(target=gst.time_make)
        self.t.start()

    def game_start_game(self):
        self.close()
        gsg.show()
        self.t2 = Thread(target=gsg.time_make)
        self.t2.start()

    def break_game(self):
        self.close()

    def How_to_play(self):
        self.close()
        htp.show()

class Worker():
    def __init__(self):
        super(Worker,self).__init__()

#时间模式开始游戏
class game_start_time(QMainWindow,Ui_gaming_time):
    def __init__(self,parent=None):
        super(game_start_time,self).__init__(parent)
        self.setupUi(self)
        self.pushButton.clicked.connect(self.Bingo)
        self.pushButton_2.clicked.connect(self.Next_item)

        self.bingo = 0
        self.num = 1

        list_item = self.item_list()
        nn = randint(0, len(list_item))
        que = list_item.pop(nn)
        # print(que)
        question = str(self.num) + '.' + que
        # print(self.num)
        self.num += 1
        self.label.setText(question)

    def time_make(self):
        # 时间准备
        self.time1 = QTimer(self)
        # self.time1.setInterval(1000)
        self.time_count = 5
        while True:
            # print("此线程正在执行")
            self.time_count -= 1
            time.sleep(1)
            text = "%d:%02d" % (self.time_count / 60, self.time_count % 60)
            self.lcdNumber.display(text)
            print(self.time_count)
            if self.time_count == 0:
                self.count = 0
                # 显示"时间结束啦",并进行移动调整
                self.label.setText("时间结束啦!!!")
                self.label.setGeometry(QtCore.QRect(150, 80, 300, 81))
                # 将"答对了"按键移动出屏幕外
                self.pushButton.move(-1000, -1000)
                # 将"下一题"按键移动出屏幕外
                self.pushButton_2.move(-1000, -1000)
                # 将"返回主菜单"按键移动出屏幕内
                self.pushButton_3.move(200, 270)
                # 将显示"返回结果"改为"您总共答对了%d题!!",并移动进入屏幕内
                self.label_2.setText("您总共答对了%d题!!" % self.bingo)
                self.label_2.setGeometry(QtCore.QRect(150, 150, 300, 81))
                # 将"返回主菜单"按键触发返回发到主菜单
                self.pushButton_3.clicked.connect(self.back_main)
                break

    #初始化函数,将一切初始化
    def back_main(self):
        #初始化"答对了"按钮位置
        self.pushButton.setGeometry(QtCore.QRect(100, 270, 130, 40))
        # 初始化"下一题"按钮位置
        self.pushButton_2.setGeometry(QtCore.QRect(330, 270, 130, 40))
        # 初始化"返回主菜单"按钮位置
        self.pushButton_3.setGeometry(QtCore.QRect(-1000, 270, 130, 40))
        #初始化"准备开始"文本
        self.label.setGeometry(QtCore.QRect(210, 80, 281, 81))
        self.label.setText("准备开始!")
        #将"您总共答对了%d题!!"移出屏幕外
        self.label_2.setGeometry(QtCore.QRect(-1000, 80, 281, 81))
        self.label_2.setText("返回答对题目的数目")
        self.setStyleSheet("#Dialog{border-image:url(images/主页.png);}")
        self.bingo = 0
        self.num = 1
        self.time_count = 180
        list_item = self.item_list()
        nn = randint(0, len(list_item))
        que = list_item.pop(nn)
        # print(que)
        question = str(self.num) + '.' + que
        self.num +=1
        self.label.setText(question)
        # self.time1.stop()
        a.t.join()
        self.close()
        a.show()


    def Bingo(self):
        self.time1.start()
        list_item = self.item_list()
        nn = randint(0, len(list_item))
        que = list_item.pop(nn)
        # print(que)
        question = str(self.num) + '.' + que
        self.label.setText(question)
        self.bingo += 1
        print("+++++++++++++++")
        print("答对了%d题" % self.bingo)
        print("+++++++++++++++")
        self.num += 1

    def Next_item(self):
        self.time1.start()
        list_item = self.item_list()
        mm = randint(0, len(list_item))
        que = list_item.pop(mm)
        question = str(self.num) + '.' + que
        self.label.setText(question)
        self.num += 1

    def item_list(self):
        f = open(r"C:\Users\Python\Desktop\AID1808\中期项目\项目最终版\game_pack\item_list.txt", encoding='utf-8')
        s = f.read()
        lines = s.split('\r\n')
        for line in lines:
            list = line.split()
            # print(list)
            # print(len(list))

        f.close()
        return list

#竞猜模式游戏开始
class game_start_game(QMainWindow,Ui_gaming):

    def __init__(self,parent=None):
        super(game_start_game,self).__init__(parent)
        self.setupUi(self)
        self.pushButton.clicked.connect(self.Bingo)
        self.pushButton_2.clicked.connect(self.Next_item)

        self.bingo = 0
        self.num2 = 1

        list_item = self.item_list()
        nn = randint(0, len(list_item))
        que = list_item.pop(nn)
        # print(que)
        question = str(self.num2) + '.' + que
        self.label.setText(question)
        self.num2 += 1
        # print(self.num2)

    def time_make(self):
        # 时间准备
        self.time2 = QTimer(self)
        # self.time1.setInterval(1000)
        self.time_count = 0
        while True:
            # print("此线程正在执行")
            self.time_count += 1
            time.sleep(1)
            text = "%d:%02d" % (self.time_count / 60, self.time_count % 60)
            self.lcdNumber.display(text)
            # print(self.time_count)
            if self.num2 == 12:
                self.time2.stop()
                self.count = 0
                # 显示"时间结束啦",并进行移动调整
                self.label.setText("游戏结束")
                self.label.setGeometry(QtCore.QRect(180, 80, 300, 81))
                # 将"答对了"按键移动出屏幕外
                self.pushButton.move(-1000, -1000)
                # 将"下一题"按键移动出屏幕外
                self.pushButton_2.move(-1000, -1000)
                # 将"返回主菜单"按键移动出屏幕内
                self.pushButton_3.move(180, 270)
                # 将显示"返回结果"改为"您总共答对了%d题!!",并移动进入屏幕内
                self.label_2.setText(
                    '''您总用时%d分%02d秒,答对了%d题''' % (self.time_count / 60, self.time_count % 60, self.bingo))
                self.label_2.setGeometry(QtCore.QRect(100, 150, 300, 81))
                # 将"返回主菜单"按键触发返回发到主菜单
                self.pushButton_3.clicked.connect(self.back_main)
                break

    def Bingo(self):
        # self.time2.start()
        list_item = self.item_list()
        nn = randint(0, len(list_item))
        que = list_item.pop(nn)
        # print(que)
        question = str(self.num2) + '.' + que
        self.label.setText(question)
        self.bingo += 1
        print("+++++++++++++++")
        print("答对了%d题" % self.bingo)
        print("+++++++++++++++")
        self.num2 += 1
        if self.num2 == 12:
            self.time2.stop()
            self.count = 0
            # 显示"时间结束啦",并进行移动调整
            self.label.setText("游戏结束")
            self.label.setGeometry(QtCore.QRect(180, 80, 300, 81))
            # 将"答对了"按键移动出屏幕外
            self.pushButton.move(-1000, -1000)
            # 将"下一题"按键移动出屏幕外
            self.pushButton_2.move(-1000, -1000)
            # 将"返回主菜单"按键移动出屏幕内
            self.pushButton_3.move(180, 270)
            # 将显示"返回结果"改为"您总共答对了%d题!!",并移动进入屏幕内
            self.label_2.setText(
                '''您总用时%d分%02d秒,答对了%d题''' % (self.time_count / 60, self.time_count % 60, self.bingo))
            self.label_2.setGeometry(QtCore.QRect(100, 150, 300, 81))
            self.lcdNumber.setGeometry(QtCore.QRect(-420, 10, 71, 31))
            # 将"返回主菜单"按键触发返回发到主菜单
            self.pushButton_3.clicked.connect(self.back_main)

    def Next_item(self):
        # self.time2.start()
        list_item = self.item_list()
        mm = randint(0, len(list_item))
        que = list_item.pop(mm)
        question = str(self.num2) + '.' + que
        self.label.setText(question)
        self.num2 += 1
        if self.num2 == 12:
            self.time2.stop()
            self.count = 0
            # 显示"时间结束啦",并进行移动调整
            self.label.setText("游戏结束")
            self.label.setGeometry(QtCore.QRect(180, 80, 300, 81))
            # 将"答对了"按键移动出屏幕外
            self.pushButton.move(-1000, -1000)
            # 将"下一题"按键移动出屏幕外
            self.pushButton_2.move(-1000, -1000)
            # 将"返回主菜单"按键移动出屏幕内
            self.pushButton_3.move(180, 270)
            # 将显示"返回结果"改为"您总共答对了%d题!!",并移动进入屏幕内
            self.label_2.setText(
                '''您总用时%d分%02d秒,答对了%d题''' % (self.time_count / 60, self.time_count % 60, self.bingo))
            self.label_2.setGeometry(QtCore.QRect(100, 150, 300, 81))
            self.lcdNumber.setGeometry(QtCore.QRect(-420, 10, 71, 31))
            # 将"返回主菜单"按键触发返回发到主菜单
            self.pushButton_3.clicked.connect(self.back_main)

        # 初始化函数,将一切初始化
    def back_main(self):
        self.close()
        a.show()
        # 初始化"答对了"按钮位置
        self.pushButton.setGeometry(QtCore.QRect(100, 270, 130, 40))
        # 初始化"下一题"按钮位置
        self.pushButton_2.setGeometry(QtCore.QRect(330, 270, 130, 40))
        # 初始化"返回主菜单"按钮位置
        self.pushButton_3.setGeometry(QtCore.QRect(-1000, 270, 130, 40))
        # 初始化"准备开始"文本
        self.label.setGeometry(QtCore.QRect(210, 80, 281, 81))
        self.label.setText("准备开始!")
        # 将"您总共答对了%d题!!"移出屏幕外
        self.label_2.setGeometry(QtCore.QRect(-1000, 80, 281, 81))
        self.label_2.setText("返回答对题目的数目")
        self.setStyleSheet("#Dialog{border-image:url(images/主页.png);}")
        self.bingo = 0
        self.num2 = 1
        self.time_count = 0
        # self.close()
        list_item = self.item_list()
        nn = randint(0, len(list_item))
        que = list_item.pop(nn)
        # print(que)
        question = str(self.num2) + '.' + que
        self.num2 += 1
        self.label.setText(question)
        a.t2.join()

    def item_list(self):
        f = open(r"C:\Users\Python\Desktop\AID1808\中期项目\项目最终版\game_pack\item_list.txt", encoding='utf-8')
        s = f.read()
        lines = s.split('\r\n')
        for line in lines:
            list = line.split()
        f.close()
        return list

#更多模式
class how_to_play(QMainWindow,Ui_howtoplay):
    def __init__(self,parent=None):
        super(how_to_play,self).__init__(parent)
        self.setupUi(self)
        self.pushButton.clicked.connect(self.how_to_play)

    def how_to_play(self):
        self.close()
        a.show()

# 答题游戏类
class zhihu_main(QMainWindow, Ui_zhihu):
    def __init__(self, parent=None):
        super(zhihu_main, self).__init__(parent)
        self.setupUi(self)
        # 当选项按钮被触发时调用发送函数
        self.yes_btn.clicked.connect(self.check_choose_y)
        self.no_btn.clicked.connect(self.check_choose_n)
        # 点击开始,进入匹配
        self.start_btn.clicked.connect(self.ss)

        # 移动按钮
        self.move_btn(1)
        self.count = 4
        self.count1 = 0
        # 初始化计时
        self.time1 = QTimer(self)
        self.time1.setInterval(1000)
        self.time1.timeout.connect(self.wait_time)
        # 初始化计时
        self.time = QTimer(self)
        self.time.setInterval(1000)
        self.time.timeout.connect(self.game_time)

    # 此方法旨在,实现按钮的移动变化,减少代码重复
    def move_btn(self, n):
        if n == 1:
            self.start_btn.move(180, 290)
            self.no_btn.move(500, 500)
            self.yes_btn.move(500, 500)
        if n == 2:
            self.no_btn.move(310, 280)
            self.yes_btn.move(80, 280)
            self.start_btn.move(500, 500)

    # 发送游戏请求,等待开始
    def ss(self):
        self.q_label.setText("等待游戏开始中...")
        self.zh_game_start = Zh_Game_Thread()
        self.zh_game_start.update_date3.connect(self.game_addr)
        self.zh_game_start.update_date4.connect(self.game_tm)
        self.zh_game_start.update_date5.connect(self.game_tzz)
        self.zh_game_start.update_date6.connect(self.game_over)

        print('答题游戏开始')
        self.zh_game_start.start()
        # 移动按钮
        self.move_btn(2)

    def game_tzz(self, msg):
        print(msg[1])
        kk = []
        for i in msg[1]:
            kk.append(i)
            kk.append(msg[1][i])
        try:
            self.player_1.setText("%s:" % kk[0])
            self.player_2.setText("%s分" % kk[1])
            self.player_3.setText("%s:" % kk[2])
            self.player_4.setText("%s分" % kk[3])
            self.player_5.setText("%s:" % kk[4])
            self.player_6.setText("%s分" % kk[5])
            self.player_7.setText("%s:" % kk[6])
            self.player_8.setText("%s分" % kk[7])
        except:
            pass

    # 游戏开始后接收题目,并计时,移动按钮

    def game_tm(self, msg):
        # 显示题目
        # print(msg)
        if msg[0] == 'TM':
            self.q_label.setText(msg[1])
            # 开始计时
            # self.time.start()
            self.yes_btn.setEnabled(True)
            self.no_btn.setEnabled(True)
        elif msg[0] == 'JX':
            self.q_label.setText(msg[1])

    # 此方法,在系统发题后,开始倒计时,
    # 时间到,判断正误
    def game_time(self):
        print('答题倒计时...')
        if self.count >= 0:
            self.time_l.setText('time: '+str(self.count)+'s')
            self.count -= 1
        else:
            self.time.stop()
            self.time_l.setText("Wating..")
            self.count = 4
            self.yes_btn.setEnabled(True)
            self.no_btn.setEnabled(True)
            # self.game_over()

    # 此方法旨在,退出一次游戏后,初始化游戏界面以及按钮绑定
    # 如果有更好的方法,可以加以修改
    def reboot_game(self):
        self.start_btn.setText("匹配")
        self.yes_btn.setText("√")
        self.no_btn.setText("×")
        self.time_l.setText("点击匹配,等待玩家加入")
        self.tishi.setText("剩余挑战者")
        self.q_label.setText("welcome!")
        self.player_1.setText("玩家")
        self.player_2.setText("玩家")
        self.player_3.setText("玩家")
        self.player_4.setText("玩家")
        self.player_5.setText("玩家")
        self.player_6.setText("玩家")
        self.player_7.setText("玩家")
        self.player_8.setText("玩家")
        self.move_btn(1)
        self.start_btn.clicked.connect(self.ss)
        self.zh_game_start = ''
        # self.close_sign.emit()
        # self.zh_game_start.close()

    # 判断用户的按钮选项,如果错误,弹出分数,初始化游戏界面
    def check_choose_y(self):
        self.yes_btn.setEnabled(False)
        self.no_btn.setEnabled(False)
        s_game.sendto(str(['DA', dl.name, '对']).encode(), self.ADDR2)

    def check_choose_n(self):
        self.yes_btn.setEnabled(False)
        self.no_btn.setEnabled(False)
        s_game.sendto(str(['DA', dl.name, '错']).encode(), self.ADDR2)

    def game_addr(self, ad):
        self.ADDR2 = eval(ad)

    def game_over(self, msgl):
        QMessageBox.information(self, '很遗憾', str(msgl), QMessageBox.Yes)
        # ==================================================
        zh.destroy()
        self.reboot_game()

    # 此为,匹配对手时的倒计时,以免出现界面卡死
    def wait_time(self):
        print('匹配计时中..')
        if self.count1 <= 10:
            self.time_l.setText('匹配中:'+str(self.count)+'s...')
            self.count1 += 1
        else:
            self.time.stop()
            self.q_label.setText("暂未匹配到对手,请重试")
            self.count1 = 0


# 定义三个常量函数，用来表示白棋，黑棋，以及 空
EMPTY = 0
BLACK = 1
WHITE = 2
black_color = [0, 0, 0]
white_color = [255, 255, 255]

# 定义棋盘类
class Chessboard(object):
    def __init__(self):
        self.board = [[]] * 15
        self.reset()
        pygame.init()
        
    # 重置棋盘
    def reset(self):
        for row in range(len(self.board)):
            self.board[row] = [EMPTY] * 15

    # 定义棋盘上的下棋函数，row表示行，col表示列，is_black表示判断当前点位该下黑棋，还是白棋
    def move(self, row, col, is_black):
        if self.board[row][col] == EMPTY:
            self.board[row][col] = BLACK if is_black else WHITE
            return True
        return False

    # 画棋盘，并且将下了的棋子也画出来
    def draw(self, screen):
        for h in range(1, 16):
            pygame.draw.line(screen, black_color, [40, h * 40], [600, h * 40], 1)
            pygame.draw.line(screen, black_color, [h * 40, 40], [h * 40, 600], 1)
        # 给棋盘加一个外框
        pygame.draw.rect(screen, black_color, [36, 36, 568, 568], 3)
        # 在棋盘上标出5个特殊点
        pygame.draw.circle(screen, black_color, [320, 320], 5, 0)
        pygame.draw.circle(screen, black_color, [160, 160], 3, 0)
        pygame.draw.circle(screen, black_color, [160, 480], 3, 0)
        pygame.draw.circle(screen, black_color, [480, 160], 3, 0)
        pygame.draw.circle(screen, black_color, [480, 480], 3, 0)
        # 取得棋盘上所有交叉点的坐标
        for row in range(len(self.board)):
            for col in range(len(self.board[row])):
                # 将下在棋盘上的棋子画出来
                if self.board[row][col] != EMPTY:
                    ccolor = black_color if self.board[row][col] == BLACK else white_color
                    # 取得这个交叉点下的棋子的颜色，并将棋子画出来
                    # pos = [40 * (col + 1), 40 * (row + 1)]
                    # # 画出棋子
                    # pygame.draw.circle(screen, ccolor, pos, 18, 0)
                    pos = (40 * (col + 1) - 18, 40 * (row + 1) - 18)
                    # 画出棋子
                    if ccolor == black_color:
                        black=pygame.image.load(r'C:\Users\Python\Desktop\AID1808\中期项目\项目最终版\black.png')
                        black=pygame.transform.smoothscale(black,(36,36))
                        screen.blit(black,pos)
                    else:
                        white=pygame.image.load(r'C:\Users\Python\Desktop\AID1808\中期项目\项目最终版\white.png')
                        white=pygame.transform.smoothscale(white,(36,36))
                        screen.blit(white,pos)

    def rG2_main(self, addr, mark):
        # 创建棋盘对象
        board = Chessboard()
        is_black = True
        # pygame初始化函数
        pygame.init()
        # 设置标题
        pygame.display.set_caption('五子棋')
        # 设置一个窗口
        screen = pygame.display.set_mode((700, 640))
        # 给窗口填充颜色
        screen.fill([255,255,255])
        # 将棋盘画出来将
        board.draw(screen)
        # 刷新窗口显示
        pygame.display.flip()

        # 如果标记为1,下黑棋
        if mark == "1":
            print("你使用黑棋")
            screen.fill([255,255,255])
            board.draw(screen)
            Text = pygame.font.SysFont('simhei', 20)
            textSurface = Text.render("该你下了!", True, (0, 0, 0))
            TextRect = textSurface.get_rect()
            TextRect.center = ((650), (640/2))
            screen.blit(textSurface, TextRect)
            pygame.display.flip()
        # 如果标记为2,下白棋
        elif mark == "2":
            print("你使用白棋")
            print("正在等待对手走棋")
            # 设置堵塞事件列表
            pygame.event.set_blocked([pygame.MOUSEBUTTONDOWN])
            data, addr = self.s_rG2.recvfrom(1024)
            # 设置允许事件列表
            pygame.event.set_allowed([pygame.MOUSEBUTTONDOWN])
            data = data.decode()

            l = data.split("#")
            row = int(l[0])
            col = int(l[1])
            # 判断这个格子有没有被占用
            if board.move(row, col, is_black):
                screen.fill([255,255,255])
                board.draw(screen)
                Text = pygame.font.SysFont('simhei', 20)
                textSurface = Text.render("该你下了!", True, (0, 0, 0))
                TextRect = textSurface.get_rect()
                TextRect.center = ((650), (640/2))
                screen.blit(textSurface, TextRect)
                pygame.display.flip()
            is_black = not is_black

        while True:
            # try:
            for event in pygame.event.get():
                if event.type == pygame.QUIT or (event.type == pygame.KEYUP and event.key == pygame.K_ESCAPE):
                    # running = False
                    msg = "end"
                    self.s_rG2.sendto(msg.encode(), addr)
                    pygame.quit()
                    # sys.exit()
                # elif event.type == pygame.KEYUP:
                #     # pass
                #     pygame.quit()
                # pygame.MOUSEBUTTONDOWN表示鼠标的键被按下
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # button表示鼠标左键
                    pygame.mixer.Sound('./sound.wav').play()
                    x, y = event.pos  # 拿到鼠标当前在窗口上的位置坐标
                    # 将鼠标的(x, y)窗口坐标，转化换为棋盘上的坐标
                    row = round((y - 40) / 40)
                    col = round((x - 40) / 40)
                    if row < 0 or row > 14 or col < 0 or col > 14:
                        continue
                    l = [str(row), str(col)]
                    data = "#".join(l)

                    if board.move(row, col, is_black):
                        screen.fill([255,255,255])
                        board.draw(screen)
                        pygame.display.flip()
                        self.s_rG2.sendto(data.encode(), addr)
                        print("正在等待对方下棋")
                        # 设置堵塞事件列表
                        pygame.event.set_blocked([pygame.MOUSEBUTTONDOWN])

                        data, addr = self.s_rG2.recvfrom(1024)
                        print("对方下棋啦")
                        # 设置允许事件列表
                        pygame.event.set_allowed([pygame.MOUSEBUTTONDOWN])

                        is_black = not is_black
                        data = data.decode()
                        if data == "Y":
                            print("你赢了")
                            # running = False
                            # 在窗口上显示字幕
                            screen.fill([255,255,255])
                            # 通过字体文件获得字体对象
                            # Text = pygame.font.Font('freesansbold.ttf',115)
                            Text = pygame.font.SysFont('simhei', 90)
                            # 配置要显示的文字
                            pygame.mixer.Sound('./win.wav').play()
                            textSurface = Text.render(
                                "你操作太秀了!", True, (0, 0, 0))
                            msgll=["WZQSL",self.name]
                            self.s_rG2.sendto(str(msgll).encode(),ADDR)
                            # 获得要显示的对象的rect
                            TextRect = textSurface.get_rect()
                            # 设置显示对象的坐标
                            TextRect.center = ((640/2), (640/2))
                            # 绘制字
                            screen.blit(textSurface, TextRect)
                            # 刷新窗口显示
                            pygame.display.flip()
                            time.sleep(3)
                            pygame.quit()
                            # sys.exit()
                        elif data == "N":
                            print("你输了")
                            # running = False
                            # 显示字幕
                            screen.fill([255,255,255])
                            # Text = pygame.font.Font('freesansbold.ttf',115)
                            Text = pygame.font.SysFont('simhei', 90)
                            pygame.mixer.Sound('./lose.wav').play()
                            textSurface = Text.render(
                                "别自闭!", True, (0, 0, 0))
                            TextRect = textSurface.get_rect()
                            TextRect.center = ((640/2), (640/2))
                            screen.blit(textSurface, TextRect)
                            pygame.display.flip()
                            time.sleep(3)
                            pygame.quit()
                            # sys.exit()
                        else:
                            l = data.split("#")
                            row = int(l[0])
                            col = int(l[1])
                            board.move(row, col, is_black)
                            print("is_black:", is_black)
                            screen.fill([255,255,255])
                            board.draw(screen)
                            
                            Text = pygame.font.SysFont('simhei', 20)
                            textSurface = Text.render("该你下了!", True, (0, 0, 0))
                            TextRect = textSurface.get_rect()
                            TextRect.center = ((650), (640/2))
                            screen.blit(textSurface, TextRect)
                            pygame.display.flip()

                            is_black = not is_black
            # except:
            #     print('error')
            #     return
    def start_real(self):
        self.ADDR6 = ("127.0.0.1", 33333)
        self.s_rG2 = socket(AF_INET, SOCK_DGRAM)
        msg=['WZQ',]
        self.s_rG2.sendto(str(msg).encode(), self.ADDR6)
        print("正在等待另一用户连接,请稍后,游戏即将开始...")
        while True:
            msg, addr = self.s_rG2.recvfrom(1024)
            # 消息列表msgl:["begin","1"]
            msgl = msg.decode().split(":")
            print(msgl)
            if msgl[0] == "begin":
                print('youxikaishi')
                self.rG2_main(addr, msgl[1])

    def start_5(self,name_5):
        self.name=name_5
        # name_3=dl.name
        # print(name_3)
        # p = Process(target=wzq_66.start_5,args=(name_3))
        p = Process(target=self.start_real)
        p.start()

# 数据接收与发送格式

# [意图,name,主体消息,...]

if __name__ == '__main__':
    global dl
    app = QApplication(sys.argv)
    mm = m_main()
    zh = zhihu_main()
    dl = sign_main()
    a = XYLX()
    gst = game_start_time()
    gsg = game_start_game()
    htp = how_to_play()
    dl.show()
    sys.exit(app.exec_())