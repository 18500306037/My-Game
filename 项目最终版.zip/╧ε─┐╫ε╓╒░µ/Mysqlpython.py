from pymysql import *
import random

#导入数据库，封装成类
class Mysqlpython:
    def __init__(self,database,host = "localhost",
                 user = "root",passwd = "123456",
                 charset = "utf8",port = 3306):
        self.database = database
        self.host = host
        self.user = user
        self.passwd = passwd
        self.charset = charset
        self.port = port
    
    #创建数据库连接对象和游标对象
    def open(self):
        self.db = connect(host = self.host,user = self.user,
                          passwd = self.passwd,port = self.port,
                          database = self.database,
                          charset = self.charset)
        self.cur = self.db.cursor()

    #关闭游标对象和数据库连接
    def close(self):
        self.cur.close()
        self.db.close()
    
    #执行sql命令
    def zhixing(self,sql,L = []):
        self.open()
        self.cur.execute(sql,L)
        self.db.commit()
        self.close()
    
    #查询sql命令
    def chaxun(self,sql,L = []):
        self.open()
        self.cur.execute(sql,L)
        result = self.cur.fetchall()
        return result

if __name__ == "__main__":
    sqlh = Mysqlpython("project")
    sql = "select * from admin;"
    presult = sqlh.chaxun(sql)
    # l = []
    # for i in presult:
    #     l.append(i[1])
    # L = random.sample(l,3)
    print(presult)