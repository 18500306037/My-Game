# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\Python\Desktop\1.0\base\main.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
from PyQt5.QtCore import Qt
from PyQt5 import QtCore, QtGui, QtWidgets

class main_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        # MainWindow.resize(811, 422)
        MainWindow.resize(811, 571)
        MainWindow.setMinimumSize(QtCore.QSize(810, 570))
        MainWindow.setMaximumSize(QtCore.QSize(810, 570))
        MainWindow.setWindowFlags(Qt.WindowMinimizeButtonHint | Qt.WindowCloseButtonHint )

        MainWindow.setStyleSheet('#MainWindow{border-image:url(主界面.jpg);}')
        MainWindow.setWindowIcon(QtGui.QIcon('tt.png'))
        # self.setGeometry(811, 571, 290, 150)
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        self.centralWidget.setObjectName("centralWidget")
        self.lineEdit = QtWidgets.QLineEdit(self.centralWidget)
        self.lineEdit.setGeometry(QtCore.QRect(1, 390, 538, 31))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.setStyleSheet('#lineEdit{font-family:"微软雅黑";}')

        self.send_msg_btn = QtWidgets.QPushButton(self.centralWidget)
        self.send_msg_btn.setGeometry(QtCore.QRect(458, 390, 81, 31))
        self.send_msg_btn.setObjectName("send_msg_btn")
        self.send_msg_btn.setStyleSheet('background-color:#64a131;color:#F0FFFF;')

        self.dati_game = QtWidgets.QPushButton(self.centralWidget)
        self.dati_game.setGeometry(QtCore.QRect(0, 420, 271, 151))
        self.dati_game.setObjectName("dati_game")
        self.dati_game.setStyleSheet("border:1px")
        
        dticon = QtGui.QIcon()
        dticon.addPixmap(QtGui.QPixmap("吃鸡.jpg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.dati_game.setIcon(dticon)
        self.dati_game.setIconSize(QtCore.QSize(268,148))
        
        self.pushButton_5 = QtWidgets.QPushButton(self.centralWidget)
        self.pushButton_5.setGeometry(QtCore.QRect(270, 420, 271, 151))
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_5.setStyleSheet("border:1px")
        
        
            
        pb5icon = QtGui.QIcon()
        pb5icon.addPixmap(QtGui.QPixmap("五子棋.jpg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_5.setIcon(pb5icon)
        self.pushButton_5.setIconSize(QtCore.QSize(268,150))


        
        self.pushButton_7 = QtWidgets.QPushButton(self.centralWidget)
        self.pushButton_7.setGeometry(QtCore.QRect(540, 420, 271, 151))
        self.pushButton_7.setObjectName("pushButton_7")
        self.pushButton_7.setStyleSheet("border:1px")
             
        pb7icon = QtGui.QIcon()
        pb7icon.addPixmap(QtGui.QPixmap("更多22.jpg"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.pushButton_7.setIcon(pb7icon)
        self.pushButton_7.setIconSize(QtCore.QSize(268,148))


        
        self.textBrowser = QtWidgets.QTextBrowser(self.centralWidget)
        self.textBrowser.setGeometry(QtCore.QRect(1, 220, 538, 171))
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser.setStyleSheet("background-color:#40F0FFFF;font-family:'微软雅黑'")
        font1 = QtGui.QFont()
        font1.setFamily("黑体")
        font1.setPointSize(14)

        self.uname_lab = QtWidgets.QLabel(self.centralWidget)
        self.uname_lab.setGeometry(QtCore.QRect(80, 0, 251, 81))
        self.uname_lab.setFont(font1)
        self.uname_lab.setObjectName("label")
        
        # self.uname_lab.setStyleSheet("color:#F0FFFF")
        self.label_2 = QtWidgets.QLabel(self.centralWidget)
        self.label_2.setGeometry(QtCore.QRect(540, 0, 271,61))
        font = QtGui.QFont()
        font.setFamily("华文琥珀")
        font.setPointSize(16)
        self.label_2.setFont(font)
        self.label_2.setAlignment(Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.line = QtWidgets.QFrame(self.centralWidget)
        self.line.setGeometry(QtCore.QRect(530, 100, 21, 320))
        self.line.setFrameShape(QtWidgets.QFrame.VLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        
        self.label_3 = QtWidgets.QLabel(self.centralWidget)
        self.label_3.setGeometry(QtCore.QRect(540, 60, 271, 31))
        self.label_3.setAlignment(Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(14)
        self.label_3.setFont(font)

        self.label_4 = QtWidgets.QLabel(self.centralWidget)
        self.label_4.setGeometry(QtCore.QRect(570, 111, 250, 21))
        self.label_4.setObjectName("label_4")
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(9)
        self.label_4.setFont(font)

        self.label_5 = QtWidgets.QLabel(self.centralWidget)
        self.label_5.setGeometry(QtCore.QRect(570, 140, 250, 21))
        self.label_5.setObjectName("label_5")
        self.label_5.setFont(font)

        self.label_6 = QtWidgets.QLabel(self.centralWidget)
        self.label_6.setGeometry(QtCore.QRect(570, 170, 250, 21))
        self.label_6.setObjectName("label_6")
        self.label_6.setFont(font)

        self.label_7 = QtWidgets.QLabel(self.centralWidget)
        self.label_7.setGeometry(QtCore.QRect(540, 220, 271, 31))
        self.label_7.setAlignment(Qt.AlignCenter)
        self.label_7.setObjectName("label_7")
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(14)
        self.label_7.setFont(font)

        self.label_8 = QtWidgets.QLabel(self.centralWidget)
        self.label_8.setGeometry(QtCore.QRect(570, 310, 250, 21))
        self.label_8.setObjectName("label_8")
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(9)
        self.label_8.setFont(font)

        self.label_9 = QtWidgets.QLabel(self.centralWidget)
        self.label_9.setGeometry(QtCore.QRect(570, 281, 250, 21))
        self.label_9.setObjectName("label_9")
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(9)
        self.label_9.setFont(font)

        self.label_10 = QtWidgets.QLabel(self.centralWidget)
        self.label_10.setGeometry(QtCore.QRect(570, 251, 250, 21))
        self.label_10.setObjectName("label_10")
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(9)
        self.label_10.setFont(font)

        self.toplist_lb = QtWidgets.QLabel(self.centralWidget)
        self.toplist_lb.setGeometry(QtCore.QRect(540, 350, 271, 61))
        font = QtGui.QFont()
        font.setFamily("华文琥珀")
        font.setPointSize(13)
        self.toplist_lb.setFont(font)
        self.toplist_lb.setObjectName("toplist_lb")
        self.toplist_lb.setAlignment(Qt.AlignCenter)
        
        self.label_16 = QtWidgets.QLabel(self.centralWidget)
        self.label_16.setGeometry(QtCore.QRect(80, 60, 400, 221))
        self.label_16.setObjectName("label_16")
        # self.label_16.setStyleSheet("color:#F0FFFF")
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(12)
        self.label_16.setFont(font)

        
        MainWindow.setCentralWidget(self.centralWidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Chating & Gaming"))
        self.send_msg_btn.setText(_translate("MainWindow", "发送"))
        # self.dati_game.setText(_translate("MainWindow", "之乎者也"))
        # self.pushButton_5.setText(_translate("MainWindow", "五子棋"))
        # self.pushButton_7.setText(_translate("MainWindow", "更多..."))
        # self.pushButton_8.setText(_translate("MainWindow", "选择游戏"))
        self.textBrowser.setHtml(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'SimSun\'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.uname_lab.setText(_translate("MainWindow", "欢迎用户:上帝之手"))
        self.label_2.setText(_translate("MainWindow", "巅峰排行榜"))
        self.label_3.setText(_translate("MainWindow", "最强头脑"))
        self.label_4.setText(_translate("MainWindow", "1-1"))
        self.label_5.setText(_translate("MainWindow", "1-2"))
        self.label_6.setText(_translate("MainWindow", "1-3"))
        self.label_7.setText(_translate("MainWindow", "棋中王者"))
        self.label_10.setText(_translate("MainWindow", "2-1"))
        self.label_9.setText(_translate("MainWindow", "2-2"))
        self.label_8.setText(_translate("MainWindow", "2-3"))
        # self.label_11.setText(_translate("MainWindow", "划水强者"))
        self.toplist_lb.setText(_translate("MainWindow", "<a href='#' style='color:red'>点击刷新排行榜</a>"))
        self.label_16.setText(_translate("MainWindow", '''
<<<系统通知>>>
Chating & Gaming 2.0演示版,将于2018年 12月 08日
开启内测.欢迎广大内测用户,提出宝贵意见.
'''))
    def zhankai(self,Mainwindow):
        MainWindow.resize(811, 571)

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = main_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

